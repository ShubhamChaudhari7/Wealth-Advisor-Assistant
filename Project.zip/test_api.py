import json
import requests

def test_api():
    base_url = "http://127.0.0.1:8000"
    print("1. Calling /api/v1/health...")
    r = requests.get(f"{base_url}/api/v1/health")
    assert r.status_code == 200
    print("Health response:", r.json())

    print("\n2. Calling /api/v1/analyze with sample_client_conservative.json...")
    with open("samples/sample_client_conservative.json", "r") as f:
        client_data = json.load(f)

    r = requests.post(f"{base_url}/api/v1/analyze", json=client_data)
    assert r.status_code == 200
    res = r.json()
    print("Analysis status:", res.get("status"))
    print("Requires human approval:", res.get("requires_human_approval"))
    print("Anomalies count:", len(res.get("anomalies", [])))

    session_id = res.get("session_id")
    print(f"\n3. Submitting Human Review for session {session_id}...")
    review_payload = {
        "session_id": session_id,
        "approved": True,
        "advisor_notes": "Advisor verification: Approved rebalance. Trim equities to 35% cap, reallocate into BND treasuries."
    }
    r = requests.post(f"{base_url}/api/v1/review", json=review_payload)
    assert r.status_code == 200
    final_res = r.json()
    print("Final status:", final_res.get("status"))
    report = final_res.get("advisory_report")
    print("Health Score:", report.get("financial_health_score"))
    print("Rebalance trades recommended:", len(report.get("rebalance_plan", [])))
    print("Actionable recommendations:", len(report.get("actionable_recommendations", [])))

    print("\n4. Calling /api/v1/history/CLI-1001...")
    r = requests.get(f"{base_url}/api/v1/history/CLI-1001")
    assert r.status_code == 200
    hist = r.json()
    print("Historical sessions count:", hist.get("total_historical_sessions"))

    # Save sample output
    with open("samples/sample_api_output.json", "w") as f:
        json.dump(final_res, f, indent=2)
    print("\nSaved samples/sample_api_output.json successfully!")

if __name__ == "__main__":
    test_api()
