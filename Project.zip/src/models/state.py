from typing import TypedDict, Optional, List, Dict, Any
from src.models.schemas import (
    ClientFinancialData,
    CRMClientContext,
    FinancialAnalysisResult,
    Anomaly,
    WealthAdvisoryReport,
    ExecutionAuditLog
)

class AdvisorState(TypedDict):
    session_id: str
    client_id: str
    financial_data: Optional[Dict[str, Any]]
    crm_context: Optional[Dict[str, Any]]
    market_benchmarks: Optional[Dict[str, Any]]
    analysis_result: Optional[Dict[str, Any]]
    anomalies: List[Dict[str, Any]]
    requires_human_approval: bool
    is_approved_by_human: bool
    advisor_override_notes: Optional[str]
    advisory_report: Optional[Dict[str, Any]]
    current_step: str
    status: str
    error: Optional[str]
    audit_logs: List[Dict[str, Any]]
    long_term_memory_context: Optional[Dict[str, Any]]
