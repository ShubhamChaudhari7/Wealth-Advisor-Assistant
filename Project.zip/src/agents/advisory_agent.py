import datetime
from typing import Dict, Any, List
from src.models.state import AdvisorState
from src.models.schemas import (
    WealthAdvisoryReport,
    RebalanceRecommendation,
    AdvisoryRecommendation,
    Anomaly
)
from src.memory.long_term import LongTermMemoryStore
from src.config import GROQ_API_KEY, GROQ_MODEL, get_logger

logger = get_logger("advisory_agent")

class AdvisoryAgent:
    """
    Advisory Agent:
    Translates quantitative analysis, detected anomalies, CRM goals,
    and advisor overrides into a structured Wealth Advisory Report.
    """
    def __init__(self):
        self.long_term_memory = LongTermMemoryStore()

    def run(self, state: AdvisorState) -> Dict[str, Any]:
        session_id = state["session_id"]
        logger.info(f"[{session_id}] Advisory Agent formulating wealth plan.")
        audit_logs = list(state.get("audit_logs", []))

        client_id = state.get("client_id", "UNKNOWN")
        fin_data = state.get("financial_data") or {}
        profile = fin_data.get("client_profile", {})
        client_name = profile.get("name", "Valued Client")
        risk_tolerance = profile.get("risk_tolerance", "Moderate")

        analysis = state.get("analysis_result") or {}
        crm = state.get("crm_context") or {}
        market = state.get("market_benchmarks") or {}
        anomalies = state.get("anomalies") or []
        advisor_notes = state.get("advisor_override_notes")
        is_override = bool(advisor_notes)
        hist_context = state.get("long_term_memory_context") or {}

        # 1. Compute Rebalance Plan
        rebalance_plan = self._compute_rebalance_plan(analysis, market)

        # 2. Compute Health Score
        health_score = self._compute_health_score(analysis, anomalies)

        # 3. Generate Advisory Recommendations
        recommendations = self._generate_recommendations(analysis, anomalies, crm, profile, rebalance_plan)

        # 4. Generate Executive Summary & Risk Assessment
        exec_summary, risk_summary = self._generate_summaries(
            client_name=client_name,
            risk_tolerance=risk_tolerance,
            analysis=analysis,
            anomalies=anomalies,
            crm=crm,
            advisor_notes=advisor_notes,
            hist_context=hist_context,
            health_score=health_score
        )

        # 5. Build Final Structured Wealth Advisory Report
        report = WealthAdvisoryReport(
            client_id=client_id,
            client_name=client_name,
            report_date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            financial_health_score=health_score,
            executive_summary=exec_summary,
            risk_assessment_summary=risk_summary,
            rebalance_plan=rebalance_plan,
            actionable_recommendations=recommendations,
            critical_anomalies_flagged=[Anomaly(**a) for a in anomalies if a.get("severity") in ["CRITICAL", "HIGH"]],
            advisor_override_applied=is_override,
            advisor_notes=advisor_notes
        ).model_dump()

        # 6. Persist to Long-Term Memory
        self.long_term_memory.save_session(
            client_id=client_id,
            session_id=session_id,
            net_worth=analysis.get("net_worth", 0.0),
            total_assets=analysis.get("total_assets", 0.0),
            total_liabilities=analysis.get("total_liabilities", 0.0),
            health_score=health_score,
            asset_allocation=analysis.get("asset_allocation", {}),
            executive_summary=exec_summary,
            anomalies_count=len(anomalies),
            advisor_notes=advisor_notes
        )

        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "AdvisoryAgent",
            "action": "Generate Wealth Advisory Report",
            "details": f"Generated comprehensive report with Health Score {health_score}/100 and {len(recommendations)} strategic recommendations.",
            "status": "SUCCESS"
        })

        return {
            "advisory_report": report,
            "audit_logs": audit_logs,
            "current_step": "REPORT_COMPLETED",
            "status": "COMPLETED"
        }

    def _compute_rebalance_plan(self, analysis: Dict[str, Any], market: Dict[str, Any]) -> List[RebalanceRecommendation]:
        current_alloc = analysis.get("asset_allocation", {})
        total_assets = analysis.get("total_assets", 0.0)
        target_alloc = market.get("target_model_allocation", {
            "Equity": 55.0, "Fixed Income": 30.0, "Cash": 5.0, "Real Estate": 10.0, "Crypto": 0.0, "Alternative": 0.0
        })

        all_categories = sorted(list(set(list(current_alloc.keys()) + list(target_alloc.keys()))))
        plan: List[RebalanceRecommendation] = []

        for cat in all_categories:
            curr_pct = current_alloc.get(cat, 0.0)
            targ_pct = target_alloc.get(cat, 0.0)
            diff_pct = round(curr_pct - targ_pct, 2)
            trade_amount = round(abs(diff_pct / 100.0) * total_assets, 2)

            if diff_pct > 2.0:
                action = "DECREASE"
                rationale = f"Current allocation of {curr_pct:.1f}% exceeds target {targ_pct:.1f}%. Trim position to mitigate exposure."
            elif diff_pct < -2.0:
                action = "INCREASE"
                rationale = f"Current allocation of {curr_pct:.1f}% is below target {targ_pct:.1f}%. Capital addition recommended to align with mandate."
            else:
                action = "HOLD"
                trade_amount = 0.0
                rationale = f"Position is in alignment with target model ({curr_pct:.1f}% vs {targ_pct:.1f}% target)."

            plan.append(RebalanceRecommendation(
                asset_category=cat,
                current_pct=curr_pct,
                target_pct=targ_pct,
                adjustment_action=action,
                estimated_trade_amount=trade_amount,
                rationale=rationale
            ))
        return plan

    def _compute_health_score(self, analysis: Dict[str, Any], anomalies: List[Dict[str, Any]]) -> int:
        score = 100
        
        # Debt leverage impact
        debt_ratio = analysis.get("debt_to_asset_ratio", 0.0)
        if debt_ratio > 0.6:
            score -= 25
        elif debt_ratio > 0.4:
            score -= 15
        elif debt_ratio > 0.2:
            score -= 5

        # Emergency fund shortfall
        emer_months = analysis.get("emergency_fund_months", 0.0)
        if emer_months < 1.0:
            score -= 20
        elif emer_months < 3.0:
            score -= 10

        # Cash flow deficit
        if analysis.get("monthly_cash_flow_surplus", 0.0) < 0:
            score -= 20

        # Anomalies penalty
        for anom in anomalies:
            sev = anom.get("severity", "LOW")
            if sev == "CRITICAL":
                score -= 15
            elif sev == "HIGH":
                score -= 10
            elif sev == "MEDIUM":
                score -= 5

        # Single asset concentration
        if analysis.get("concentration_risks"):
            score -= 10

        return max(15, min(100, score))

    def _generate_recommendations(
        self,
        analysis: Dict[str, Any],
        anomalies: List[Dict[str, Any]],
        crm: Dict[str, Any],
        profile: Dict[str, Any],
        rebalance_plan: List[RebalanceRecommendation]
    ) -> List[AdvisoryRecommendation]:
        recs: List[AdvisoryRecommendation] = []
        rec_counter = 1

        # 1. Anomaly mitigation recommendation
        critical_anoms = [a for a in anomalies if a.get("severity") in ["CRITICAL", "HIGH"]]
        if critical_anoms:
            actions = [f"- {a.get('description')} -> Recommended Fix: {a.get('actionable_fix')}" for a in critical_anoms]
            recs.append(AdvisoryRecommendation(
                recommendation_id=f"REC-{rec_counter}",
                title="Immediate Risk & Anomaly Containment",
                priority="HIGH",
                category="RISK_MITIGATION",
                rationale="Critical transaction outliers or policy breaches detected requiring prompt client confirmation.",
                action_steps=actions
            ))
            rec_counter += 1

        # 2. Portfolio Rebalancing recommendation
        trades_needed = [p for p in rebalance_plan if p.adjustment_action in ["INCREASE", "DECREASE"]]
        if trades_needed:
            actions = [
                f"{p.adjustment_action} {p.asset_category} by approx ${p.estimated_trade_amount:,.2f} ({p.rationale})"
                for p in trades_needed[:4]
            ]
            recs.append(AdvisoryRecommendation(
                recommendation_id=f"REC-{rec_counter}",
                title="Strategic Portfolio Realignment",
                priority="HIGH" if any(p.estimated_trade_amount > 20000 for p in trades_needed) else "MEDIUM",
                category="ASSET_ALLOCATION",
                rationale=f"Align current holdings with the client's stated {profile.get('risk_tolerance', 'Moderate')} target profile.",
                action_steps=actions
            ))
            rec_counter += 1

        # 3. Liquidity & Emergency buffer
        emer_months = analysis.get("emergency_fund_months", 0.0)
        if emer_months < 6.0:
            recs.append(AdvisoryRecommendation(
                recommendation_id=f"REC-{rec_counter}",
                title="Liquidity & Emergency Reserve Optimization",
                priority="HIGH" if emer_months < 3.0 else "MEDIUM",
                category="CASH_FLOW",
                rationale=f"Current liquid buffer of {emer_months:.1f} months is under recommended 6-month safety net.",
                action_steps=[
                    "Direct monthly cash surplus towards high-yield cash sweep (currently yielding ~4.5%).",
                    "Avoid locking funds in illiquid commitments until 6 months of living expenses are secured."
                ]
            ))
            rec_counter += 1

        # 4. Tax & Goal Planning from CRM
        stated_goals = crm.get("stated_goals", [])
        tax_bracket = crm.get("tax_bracket_pct", 24.0)
        recs.append(AdvisoryRecommendation(
            recommendation_id=f"REC-{rec_counter}",
            title="Tax-Efficient Wealth Accumulation",
            priority="MEDIUM",
            category="TAX_EFFICIENCY",
            rationale=f"Given the client's {tax_bracket:.1f}% marginal tax bracket and goals ({', '.join(stated_goals) if stated_goals else 'Growth'}), tax drag should be minimized.",
            action_steps=[
                "Maximize pre-tax retirement vehicles to shield taxable income.",
                "Utilize municipal bonds or index funds with low turnover in taxable brokerage accounts."
            ]
        ))

        return recs

    def _generate_summaries(
        self,
        client_name: str,
        risk_tolerance: str,
        analysis: Dict[str, Any],
        anomalies: List[Dict[str, Any]],
        crm: Dict[str, Any],
        advisor_notes: str | None,
        hist_context: Dict[str, Any],
        health_score: int
    ) -> tuple[str, str]:
        # Try Groq if API key configured
        if GROQ_API_KEY:
            try:
                from langchain_groq import ChatGroq
                from langchain_core.prompts import ChatPromptTemplate
                
                llm = ChatGroq(model_name=GROQ_MODEL, groq_api_key=GROQ_API_KEY, temperature=0.2)
                prompt = ChatPromptTemplate.from_template(
                    """You are a certified Private Wealth Advisor assistant. 
Create an Executive Summary (1-2 paragraphs) and Risk Assessment Summary (1 paragraph) based on:
Client: {name} (Risk Mandate: {risk})
Net Worth: ${net_worth:,.2f} | Health Score: {score}/100
Assets: ${assets:,.2f} | Liabilities: ${liabilities:,.2f} | Emergency Buffer: {emergency} months
Anomalies: {anomalies}
CRM Goals: {goals}
Advisor Override/Notes: {notes}
Historical Context: {hist}

Output in format:
EXECUTIVE_SUMMARY: <text>
RISK_ASSESSMENT: <text>"""
                )
                chain = prompt | llm
                resp = chain.invoke({
                    "name": client_name,
                    "risk": risk_tolerance,
                    "net_worth": analysis.get("net_worth", 0.0),
                    "score": health_score,
                    "assets": analysis.get("total_assets", 0.0),
                    "liabilities": analysis.get("total_liabilities", 0.0),
                    "emergency": analysis.get("emergency_fund_months", 0.0),
                    "anomalies": [a.get("description") for a in anomalies],
                    "goals": crm.get("stated_goals", []),
                    "notes": advisor_notes or "None provided",
                    "hist": hist_context.get("message") or hist_context.get("historical_drift_notes", "None")
                })
                text = resp.content
                if "RISK_ASSESSMENT:" in text:
                    parts = text.split("RISK_ASSESSMENT:")
                    exec_s = parts[0].replace("EXECUTIVE_SUMMARY:", "").strip()
                    risk_s = parts[1].strip()
                    # Sanitize unicode dashes/quotes for cross-platform compatibility
                    for k, v in [('\u2011', '-'), ('\u2013', '-'), ('\u2014', '--'), ('\u2018', "'"), ('\u2019', "'"), ('\u201c', '"'), ('\u201d', '"')]:
                        exec_s = exec_s.replace(k, v)
                        risk_s = risk_s.replace(k, v)
                    return exec_s, risk_s
            except Exception as e:
                logger.warning(f"Groq generation failed: {e}. Falling back to deterministic synthesizer.")

        # Deterministic high-quality synthesis
        net_worth = analysis.get("net_worth", 0.0)
        total_assets = analysis.get("total_assets", 0.0)
        surplus = analysis.get("monthly_cash_flow_surplus", 0.0)
        num_anom = len(anomalies)

        exec_summary = (
            f"Comprehensive financial evaluation for {client_name} reveals a total net worth of ${net_worth:,.2f} "
            f"across ${total_assets:,.2f} in gross assets with a calculated Financial Health Score of {health_score}/100. "
            f"The client's stated risk tolerance is '{risk_tolerance}', with primary relationship goals centered on "
            f"{', '.join(crm.get('stated_goals', ['Long-Term Wealth Growth']))}. Monthly net cash flow remains at a "
            f"${surplus:,.2f} surplus. "
        )

        if hist_context.get("has_previous_session"):
            exec_summary += (
                f"Historical comparison with prior review ({hist_context.get('previous_session_date')}) indicates a "
                f"${hist_context.get('net_worth_change'):,.2f} ({hist_context.get('net_worth_pct_change'):+.1f}%) net worth adjustment."
            )
        else:
            exec_summary += "This report establishes the baseline diagnostic profile for future wealth tracking."

        if advisor_notes:
            exec_summary += f" [Human Wealth Advisor Instruction: {advisor_notes}]"

        risk_summary = (
            f"Risk analysis identified {num_anom} alert(s) across transactions and portfolio balance. "
            f"Debt-to-asset leverage stands at {analysis.get('debt_to_asset_ratio', 0.0):.1%}, and liquid reserves "
            f"stand at {analysis.get('emergency_fund_months', 0.0):.1f} months of expenses. "
        )
        if anomalies:
            top_anom = anomalies[0].get("description")
            risk_summary += f"Primary focal point: {top_anom}."
        else:
            risk_summary += "No critical anomalies or policy violations detected in the review period."

        return exec_summary, risk_summary
