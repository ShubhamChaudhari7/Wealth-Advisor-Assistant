import uuid
import datetime
from typing import Dict, Any, Literal
from langgraph.graph import StateGraph, END
from src.models.state import AdvisorState
from src.agents.data_fetcher_agent import DataFetcherAgent
from src.agents.analyzer_agent import AnalyzerAgent
from src.agents.advisory_agent import AdvisoryAgent
from src.memory.short_term import session_memory
from src.config import get_logger

logger = get_logger("orchestrator")

class WealthAdvisorOrchestrator:
    """
    Central Orchestrator Agent built with LangGraph.
    Coordinates execution flow between specialized agents (Data Fetcher, Analyzer, Advisory),
    evaluates conditional routing based on anomaly severity, and manages Human-in-the-Loop checkpoints.
    """
    def __init__(self):
        self.data_fetcher_agent = DataFetcherAgent()
        self.analyzer_agent = AnalyzerAgent()
        self.advisory_agent = AdvisoryAgent()
        self.graph = self._build_graph()

    def _data_fetcher_node(self, state: AdvisorState) -> Dict[str, Any]:
        return self.data_fetcher_agent.run(state)

    def _analyzer_node(self, state: AdvisorState) -> Dict[str, Any]:
        return self.analyzer_agent.run(state)

    def _human_checkpoint_node(self, state: AdvisorState) -> Dict[str, Any]:
        session_id = state["session_id"]
        logger.info(f"[{session_id}] Human-in-the-Loop checkpoint reached. Pausing for advisor validation.")
        audit_logs = list(state.get("audit_logs", []))
        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "Orchestrator",
            "action": "Human-in-the-Loop Pause",
            "details": "Execution paused. Awaiting human advisor verification of high-risk anomalies.",
            "status": "PAUSED"
        })
        return {
            "status": "AWAITING_HUMAN_APPROVAL",
            "current_step": "AWAITING_HUMAN_APPROVAL",
            "audit_logs": audit_logs
        }

    def _adviser_node(self, state: AdvisorState) -> Dict[str, Any]:
        return self.advisory_agent.run(state)

    def _routing_condition(self, state: AdvisorState) -> Literal["human_checkpoint", "adviser"]:
        requires_approval = state.get("requires_human_approval", False)
        is_approved = state.get("is_approved_by_human", False)
        
        # If approval required and not yet approved, route to human checkpoint
        if requires_approval and not is_approved:
            logger.info("Routing -> Human Checkpoint (critical risks or anomalies present)")
            return "human_checkpoint"
        
        logger.info("Routing -> Advisory Agent (approved or low-risk flow)")
        return "adviser"

    def _build_graph(self):
        workflow = StateGraph(AdvisorState)

        # Add Nodes
        workflow.add_node("data_fetcher", self._data_fetcher_node)
        workflow.add_node("analyzer", self._analyzer_node)
        workflow.add_node("human_checkpoint", self._human_checkpoint_node)
        workflow.add_node("adviser", self._adviser_node)

        # Set Entry Point
        workflow.set_entry_point("data_fetcher")

        # Define Edges
        workflow.add_edge("data_fetcher", "analyzer")
        workflow.add_conditional_edges(
            "analyzer",
            self._routing_condition,
            {
                "human_checkpoint": "human_checkpoint",
                "adviser": "adviser"
            }
        )
        workflow.add_edge("human_checkpoint", END)
        workflow.add_edge("adviser", END)

        return workflow.compile()

    def run_initial_analysis(self, financial_data: Dict[str, Any], session_id: str | None = None) -> Dict[str, Any]:
        """
        Runs the multi-agent workflow from intake through analysis.
        If high risk is detected, pauses at Human Checkpoint; otherwise completes advisory report.
        """
        session_id = session_id or f"SES-{uuid.uuid4().hex[:8]}"
        client_id = financial_data.get("client_profile", {}).get("client_id", "UNKNOWN")

        initial_state: AdvisorState = {
            "session_id": session_id,
            "client_id": client_id,
            "financial_data": financial_data,
            "crm_context": None,
            "market_benchmarks": None,
            "analysis_result": None,
            "anomalies": [],
            "requires_human_approval": False,
            "is_approved_by_human": False,
            "advisor_override_notes": None,
            "advisory_report": None,
            "current_step": "START",
            "status": "IN_PROGRESS",
            "error": None,
            "audit_logs": [{
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "Orchestrator",
                "action": "Workflow Initiated",
                "details": f"Started Wealth Advisory pipeline for client {client_id}.",
                "status": "SUCCESS"
            }],
            "long_term_memory_context": None
        }

        logger.info(f"Starting orchestration pipeline for session {session_id}...")
        result_state = self.graph.invoke(initial_state)

        # Cache state in short-term session memory
        session_memory.set_session(session_id, dict(result_state))
        return dict(result_state)

    def resume_with_human_decision(
        self,
        session_id: str,
        approved: bool = True,
        advisor_notes: str | None = None
    ) -> Dict[str, Any]:
        """
        Resumes a paused workflow after human-in-the-loop review.
        """
        cached_state = session_memory.get_session(session_id)
        if not cached_state:
            raise ValueError(f"Session {session_id} not found in short-term memory.")

        logger.info(f"[{session_id}] Resuming workflow with advisor approval={approved}, notes='{advisor_notes}'")
        audit_logs = list(cached_state.get("audit_logs", []))
        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "Orchestrator",
            "action": "Human Review Recorded",
            "details": f"Advisor decision: {'APPROVED' if approved else 'REJECTED/OVERRIDDEN'}. Notes: {advisor_notes or 'None'}.",
            "status": "SUCCESS"
        })

        cached_state["is_approved_by_human"] = approved
        cached_state["advisor_override_notes"] = advisor_notes
        cached_state["audit_logs"] = audit_logs

        # Directly execute Advisory Agent node to produce the final directive
        final_report_patch = self.advisory_agent.run(cached_state)
        cached_state.update(final_report_patch)

        # Update cache
        session_memory.set_session(session_id, cached_state)
        return cached_state
