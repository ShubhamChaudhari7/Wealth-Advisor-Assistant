import datetime
from typing import Dict, Any
from src.models.state import AdvisorState
from src.models.schemas import ClientFinancialData
from src.tools.crm_tool import MockCRMClientTool
from src.tools.market_tool import MarketBenchmarkTool
from src.config import get_logger

logger = get_logger("data_fetcher_agent")

class DataFetcherAgent:
    """
    Data Fetcher Agent:
    Retrieves and prepares financial data, validates schemas,
    and aggregates contextual data from CRM and market benchmark APIs.
    """
    def __init__(self):
        self.crm_tool = MockCRMClientTool()
        self.market_tool = MarketBenchmarkTool()

    def run(self, state: AdvisorState) -> Dict[str, Any]:
        session_id = state["session_id"]
        logger.info(f"[{session_id}] Data Fetcher Agent executing.")
        audit_logs = list(state.get("audit_logs", []))
        
        raw_fin_data = state.get("financial_data") or {}
        client_id = state.get("client_id")

        # 1. Validation and Normalization
        validation_warning = None
        try:
            validated = ClientFinancialData.model_validate(raw_fin_data)
            fin_data = validated.model_dump()
            client_id = validated.client_profile.client_id
            risk_tolerance = validated.client_profile.risk_tolerance
        except Exception as val_err:
            logger.warning(f"Validation warning: {val_err}. Utilizing fallback normalization.")
            fin_data = raw_fin_data
            client_id = raw_fin_data.get("client_profile", {}).get("client_id", client_id or "CLI-UNKNOWN")
            risk_tolerance = raw_fin_data.get("client_profile", {}).get("risk_tolerance", "Moderate")
            validation_warning = f"Data schema warning: {str(val_err)}"

        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "DataFetcherAgent",
            "action": "Ingest Client Financial Data",
            "details": f"Processed {len(fin_data.get('assets', []))} assets and {len(fin_data.get('transactions', []))} transactions for client {client_id}.",
            "status": "WARNING" if validation_warning else "SUCCESS"
        })

        # 2. Query CRM Tool Abstraction
        crm_result = self.crm_tool.execute(client_id=client_id)
        if crm_result.success:
            crm_context = crm_result.data
            logger.info(f"Successfully fetched CRM context for {client_id} in {crm_result.execution_time_ms}ms")
            audit_logs.append({
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "DataFetcherAgent",
                "action": "Query CRM Tool",
                "details": f"Retrieved CRM record from {crm_context.get('crm_source')}.",
                "status": "SUCCESS"
            })
        else:
            logger.error(f"CRM Tool error: {crm_result.error}. Applying fallback defaults.")
            crm_context = {
                "client_id": client_id,
                "relationship_status": "Fallback",
                "advisor_assigned": "Default Advisor",
                "stated_goals": ["Wealth Assessment"],
                "tax_bracket_pct": 24.0,
                "kyc_verified": True,
                "crm_source": "Offline Fallback Cache"
            }
            audit_logs.append({
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "DataFetcherAgent",
                "action": "Query CRM Tool",
                "details": f"Fallback applied due to error: {crm_result.error}",
                "status": "DEGRADED"
            })

        # 3. Query Market Benchmark Tool Abstraction
        market_result = self.market_tool.execute(risk_tolerance=risk_tolerance)
        market_benchmarks = market_result.data if market_result.success else {}
        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "DataFetcherAgent",
            "action": "Query Market Benchmark Tool",
            "details": f"Retrieved target asset allocation model for {risk_tolerance} risk profile.",
            "status": "SUCCESS"
        })

        return {
            "client_id": client_id,
            "financial_data": fin_data,
            "crm_context": crm_context,
            "market_benchmarks": market_benchmarks,
            "audit_logs": audit_logs,
            "current_step": "DATA_FETCHED",
            "status": "IN_PROGRESS"
        }
