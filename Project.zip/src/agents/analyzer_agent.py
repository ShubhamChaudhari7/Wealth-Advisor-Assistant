import datetime
from typing import Dict, Any, List
from src.models.state import AdvisorState
from src.tools.finance_tool import FinancialAnalysisTool
from src.tools.anomaly_tool import AnomalyDetectionTool
from src.memory.long_term import LongTermMemoryStore
from src.config import get_logger

logger = get_logger("analyzer_agent")

class AnalyzerAgent:
    """
    Analyzer Agent:
    Performs quantitative portfolio calculations, detects transaction/risk anomalies,
    and inspects long-term memory historical trends.
    """
    def __init__(self):
        self.finance_tool = FinancialAnalysisTool()
        self.anomaly_tool = AnomalyDetectionTool()
        self.long_term_memory = LongTermMemoryStore()

    def run(self, state: AdvisorState) -> Dict[str, Any]:
        session_id = state["session_id"]
        logger.info(f"[{session_id}] Analyzer Agent executing.")
        audit_logs = list(state.get("audit_logs", []))

        fin_data = state.get("financial_data") or {}
        client_id = state.get("client_id", "UNKNOWN")

        # 1. Execute Financial Analysis Tool Abstraction
        finance_result = self.finance_tool.execute(financial_data=fin_data)
        if not finance_result.success:
            logger.error(f"Finance tool failed: {finance_result.error}")
            analysis_dict = {}
        else:
            analysis_dict = finance_result.data
            logger.info(f"Completed financial analysis for client {client_id} in {finance_result.execution_time_ms}ms")

        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "AnalyzerAgent",
            "action": "Compute Portfolio Analytics",
            "details": f"Calculated Net Worth: ${analysis_dict.get('net_worth', 0):,.2f}, Debt-to-Asset: {analysis_dict.get('debt_to_asset_ratio', 0):.2%}.",
            "status": "SUCCESS" if finance_result.success else "ERROR"
        })

        # 2. Execute Anomaly Detection Tool Abstraction
        anomaly_result = self.anomaly_tool.execute(
            financial_data=fin_data,
            analysis_result=analysis_dict
        )
        anomalies_list = anomaly_result.data if anomaly_result.success else []
        analysis_dict["anomalies_detected"] = anomalies_list
        logger.info(f"Detected {len(anomalies_list)} anomalies for client {client_id}")

        audit_logs.append({
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "agent_name": "AnalyzerAgent",
            "action": "Anomaly Detection Execution",
            "details": f"Identified {len(anomalies_list)} anomalies/risk signals across transactions and portfolio balance.",
            "status": "SUCCESS"
        })

        # 3. Query Long-Term Memory for Historical Comparison
        historical_comparison = self.long_term_memory.get_historical_comparison(
            client_id=client_id,
            current_net_worth=analysis_dict.get("net_worth", 0.0),
            current_allocation=analysis_dict.get("asset_allocation", {})
        )
        if historical_comparison.get("has_previous_session"):
            audit_logs.append({
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "AnalyzerAgent",
                "action": "Retrieve Long-Term Memory",
                "details": f"Historical comparison found: Net worth change ${historical_comparison.get('net_worth_change'):,.2f} since {historical_comparison.get('previous_session_date')}.",
                "status": "SUCCESS"
            })
        else:
            audit_logs.append({
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "AnalyzerAgent",
                "action": "Retrieve Long-Term Memory",
                "details": "No prior session record found. Baseline initialized.",
                "status": "INFO"
            })

        # 4. Determine Human-in-the-Loop Checkpoint Necessity
        has_critical = any(a.get("severity") in ["CRITICAL", "HIGH"] for a in anomalies_list)
        high_leverage = analysis_dict.get("debt_to_asset_ratio", 0.0) > 0.45
        requires_human_approval = has_critical or high_leverage

        if requires_human_approval:
            logger.warning(f"[{session_id}] High-risk anomalies detected. Triggering Human-in-the-Loop review checkpoint.")
            audit_logs.append({
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                "agent_name": "AnalyzerAgent",
                "action": "Human-in-the-Loop Assessment",
                "details": f"Mandatory review flagged due to {len(anomalies_list)} anomalies (Critical/High severity present).",
                "status": "WARNING"
            })

        return {
            "analysis_result": analysis_dict,
            "anomalies": anomalies_list,
            "long_term_memory_context": historical_comparison,
            "requires_human_approval": requires_human_approval,
            "audit_logs": audit_logs,
            "current_step": "ANALYSIS_COMPLETED"
        }
