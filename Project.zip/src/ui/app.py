import json
import requests
import streamlit as st
import pandas as pd
from typing import Dict, Any

# Configure Streamlit Page
st.set_page_config(
    page_title="Wealth Advisor Assistant | AI Multi-Agent System",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS styling for modern executive wealth theme
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #475569;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 16px;
        text-align: center;
    }
    .badge-critical {
        background-color: #FEE2E2;
        color: #991B1B;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-high {
        background-color: #FFEDD5;
        color: #9A3412;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-medium {
        background-color: #FEF9C3;
        color: #854D0E;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-low {
        background-color: #DCFCE7;
        color: #166534;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .hitl-alert {
        background-color: #FEF3C7;
        border-left: 5px solid #F59E0B;
        padding: 16px;
        border-radius: 4px;
        margin-bottom: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# Session State Initialization
if "api_url" not in st.session_state:
    st.session_state.api_url = "http://127.0.0.1:8000"
if "current_session_id" not in st.session_state:
    st.session_state.current_session_id = None
if "workflow_state" not in st.session_state:
    st.session_state.workflow_state = None
if "selected_client_data" not in st.session_state:
    st.session_state.selected_client_data = None

# Sidebar Controls
with st.sidebar:
    st.title("💼 Wealth Advisor AI")
    st.caption("Autonomous Multi-Agent System with LangGraph")
    
    api_url = st.text_input("FastAPI Endpoint", value=st.session_state.api_url)
    st.session_state.api_url = api_url

    # Check API Health
    try:
        health_resp = requests.get(f"{api_url}/api/v1/health", timeout=2)
        if health_resp.status_code == 200:
            health_info = health_resp.json()
            st.success(f"Backend Connected ({health_info.get('llm_engine')})")
        else:
            st.error("Backend Error")
    except Exception:
        st.warning("⚠️ Backend not responding. Ensure FastAPI is running.")

    st.markdown("---")
    st.subheader("Select Client Scenario")

    # Fetch Preset Clients
    client_options = {}
    try:
        clients_resp = requests.get(f"{api_url}/api/v1/clients", timeout=2)
        if clients_resp.status_code == 200:
            for c in clients_resp.json().get("clients", []):
                label = f"{c['name']} ({c['client_id']}) - {c['risk_tolerance']}"
                client_options[label] = c["data"]
    except Exception:
        pass

    client_options["Custom JSON Upload / Editor"] = "CUSTOM"
    selected_option = st.selectbox("Client Profile", options=list(client_options.keys()))

    if selected_option == "Custom JSON Upload / Editor":
        uploaded_file = st.file_uploader("Upload Client Financial JSON", type=["json"])
        if uploaded_file is not None:
            try:
                st.session_state.selected_client_data = json.load(uploaded_file)
                st.success("JSON uploaded successfully.")
            except Exception as e:
                st.error(f"Invalid JSON: {e}")
        else:
            json_text = st.text_area("Or Paste Client JSON", height=200, value="{}")
            try:
                if json_text.strip() != "{}":
                    st.session_state.selected_client_data = json.loads(json_text)
            except Exception:
                pass
    else:
        st.session_state.selected_client_data = client_options.get(selected_option)

    st.markdown("---")
    run_btn = st.button("🚀 Run Multi-Agent Analysis", type="primary", use_container_width=True)

# Main Application Area
st.markdown('<div class="main-header">Wealth Advisor Assistant</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Multi-Agent System with Anomaly Detection, Tool Abstractions, and Human-in-the-Loop Governance</div>', unsafe_allow_html=True)

# Handle Run Analysis Action
if run_btn and st.session_state.selected_client_data:
    with st.spinner("Orchestrator Agent activating specialized agents..."):
        try:
            resp = requests.post(
                f"{st.session_state.api_url}/api/v1/analyze",
                json=st.session_state.selected_client_data,
                timeout=15
            )
            if resp.status_code == 200:
                st.session_state.workflow_state = resp.json()
                st.session_state.current_session_id = resp.json().get("session_id")
                st.success(f"Analysis Step Completed! Status: {resp.json().get('status')}")
            else:
                st.error(f"Analysis API failed: {resp.text}")
        except Exception as e:
            st.error(f"Connection failed: {e}")

# Render Workflow Dashboard if State exists
if st.session_state.workflow_state:
    state = st.session_state.workflow_state
    client_id = state.get("client_id")
    status = state.get("status")
    analysis = state.get("analysis_result") or {}
    crm = state.get("crm_context") or {}
    anomalies = state.get("anomalies") or []
    report = state.get("advisory_report")
    audit_logs = state.get("audit_logs") or []

    # Pipeline Progress Bar / Status Stepper
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.info("1. Data Ingestion & CRM\n**Complete**")
    with col2:
        st.info("2. Financial & Anomaly Analysis\n**Complete**")
    with col3:
        if status == "AWAITING_HUMAN_APPROVAL":
            st.warning("3. Human-in-the-Loop\n**Awaiting Review ⏸️**")
        else:
            st.success("3. Human-in-the-Loop\n**Verified ✅**")
    with col4:
        if status == "COMPLETED":
            st.success("4. Advisory Directives\n**Delivered 🎯**")
        else:
            st.info("4. Advisory Directives\n**Pending Gate ⏳**")

    st.markdown("---")

    # Main Tabs
    tab_overview, tab_anomalies, tab_hitl, tab_advisory, tab_memory, tab_audit = st.tabs([
        "📊 Portfolio Analytics",
        "🚨 Anomaly Detection Radar",
        "👤 Human-in-the-Loop Checkpoint",
        "📑 Final Wealth Advisory Report",
        "🧠 Long-Term Memory & Trends",
        "🔍 Agent Observability & Audit Logs"
    ])

    # TAB 1: Portfolio Analytics
    with tab_overview:
        st.subheader("Client Financial Diagnostic")
        
        # Profile Context Bar
        c_prof = st.session_state.selected_client_data.get("client_profile", {}) if st.session_state.selected_client_data else {}
        st.markdown(
            f"**Client:** {c_prof.get('name', 'N/A')} (Age {c_prof.get('age', 'N/A')}) | "
            f"**Risk Mandate:** `{c_prof.get('risk_tolerance', 'N/A')}` | "
            f"**Assigned Advisor:** {crm.get('advisor_assigned', 'N/A')} | "
            f"**CRM Status:** `{crm.get('relationship_status', 'N/A')}` | "
            f"**Tax Bracket:** `{crm.get('tax_bracket_pct', 0)}%`"
        )
        
        # Core Metrics Cards
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Net Worth", f"${analysis.get('net_worth', 0):,.2f}")
        m2.metric("Total Assets", f"${analysis.get('total_assets', 0):,.2f}")
        m3.metric("Total Liabilities", f"${analysis.get('total_liabilities', 0):,.2f}")
        m4.metric("Debt-to-Asset", f"{analysis.get('debt_to_asset_ratio', 0) * 100:.1f}%")
        m5.metric("Emergency Buffer", f"{analysis.get('emergency_fund_months', 0):.1f} mos")

        st.markdown("### Asset Allocation Breakdown")
        col_chart1, col_chart2 = st.columns([1, 1])

        # Current vs Target allocation
        alloc_dict = analysis.get("asset_allocation", {})
        market_bench = state.get("market_benchmarks", {}).get("target_model_allocation", {})

        if alloc_dict:
            df_alloc = pd.DataFrame([
                {"Category": k, "Current Allocation %": v, "Target Model %": market_bench.get(k, 0.0)}
                for k, v in alloc_dict.items()
            ]).set_index("Category")

            with col_chart1:
                st.write("**Current vs Target Allocation (%)**")
                st.bar_chart(df_alloc)

            with col_chart2:
                st.write("**Asset Allocation Amounts ($)**")
                amounts_dict = analysis.get("asset_allocation_amounts", {})
                df_amounts = pd.DataFrame([
                    {"Category": k, "Market Value ($)": v}
                    for k, v in amounts_dict.items()
                ])
                st.dataframe(df_amounts, use_container_width=True)

        if analysis.get("concentration_risks"):
            st.warning("⚠️ **Concentration Risk Detected:**\n" + "\n".join([f"- {r}" for r in analysis['concentration_risks']]))

    # TAB 2: Anomaly Detection Radar
    with tab_anomalies:
        st.subheader("Anomaly & Risk Signal Detection")
        st.write(f"The **Analyzer Agent** identified **{len(anomalies)} risk signal(s)** requiring advisory scrutiny:")

        if not anomalies:
            st.success("✅ No unusual transactions or portfolio drift anomalies detected.")
        else:
            for anom in anomalies:
                severity = anom.get("severity", "LOW")
                badge_class = f"badge-{severity.lower()}"
                
                with st.expander(f"[{severity}] {anom.get('category')} — {anom.get('description')[:75]}...", expanded=True):
                    col_a, col_b = st.columns([2, 1])
                    with col_a:
                        st.markdown(f"**Description:** {anom.get('description')}")
                        st.markdown(f"**Actionable Fix:** {anom.get('actionable_fix')}")
                    with col_b:
                        st.markdown(f"**Severity:** <span class='{badge_class}'>{severity}</span>", unsafe_allow_html=True)
                        st.markdown(f"**Detected Value:** `{anom.get('detected_value')}`")
                        st.markdown(f"**Benchmark Threshold:** `{anom.get('threshold_or_benchmark')}`")

    # TAB 3: Human-in-the-Loop Checkpoint
    with tab_hitl:
        st.subheader("Human-in-the-Loop Advisory Review Gate")

        if status == "AWAITING_HUMAN_APPROVAL":
            st.markdown("""
            <div class="hitl-alert">
                <h4>⚠️ Human Checkpoint Triggered</h4>
                <p>High-severity financial anomalies or policy violations were detected by the Analyzer Agent. 
                As mandated by Wealth Advisory Governance covenants, autonomous execution is paused. 
                A registered wealth advisor must validate or override before final directives are generated.</p>
            </div>
            """, unsafe_allow_html=True)

            advisor_input = st.text_area(
                "Advisor Strategic Instructions / Policy Overrides",
                value="Approved with note: Rebalance overweighted equity gradually over next quarter; client confirmed wire transfer legitimacy.",
                help="Enter custom notes or restrictions that will be incorporated into the final Wealth Advisory Report."
            )

            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                approve_action = st.button("✅ Authorize & Generate Advisory Directives", type="primary", use_container_width=True)
            with col_btn2:
                override_action = st.button("🚫 Override with Custom Plan", use_container_width=True)

            if approve_action or override_action:
                with st.spinner("Submitting Advisor Decision to Orchestrator..."):
                    try:
                        review_resp = requests.post(
                            f"{st.session_state.api_url}/api/v1/review",
                            json={
                                "session_id": st.session_state.current_session_id,
                                "approved": True,
                                "advisor_notes": advisor_input
                            },
                            timeout=15
                        )
                        if review_resp.status_code == 200:
                            st.session_state.workflow_state = review_resp.json()
                            st.success("Advisor Review Recorded! Final Advisory Report is ready.")
                            st.rerun()
                        else:
                            st.error(f"Error submitting review: {review_resp.text}")
                    except Exception as e:
                        st.error(f"Connection failed: {e}")
        else:
            st.success("✅ **Human-in-the-Loop Checkpoint Cleared**")
            st.write(f"Current Pipeline Status: `{status}`")
            if state.get("advisor_override_notes"):
                st.info(f"**Advisor Notes Registered:** {state.get('advisor_override_notes')}")

    # TAB 4: Final Wealth Advisory Report
    with tab_advisory:
        st.subheader("Structured Wealth Advisory Report")

        if not report:
            st.info("Report will be generated upon clearing the Human-in-the-Loop Checkpoint.")
        else:
            # Score and Meta
            col_sc1, col_sc2 = st.columns([1, 2])
            with col_sc1:
                health_score = report.get("financial_health_score", 50)
                st.metric("Financial Health Score", f"{health_score} / 100")
                st.progress(health_score / 100)
            with col_sc2:
                st.markdown(f"**Report Date:** {report.get('report_date')}")
                st.markdown(f"**Client:** {report.get('client_name')} (`{report.get('client_id')}`)")
                if report.get("advisor_override_applied"):
                    st.success(f"**Human Advisor Review Applied:** {report.get('advisor_notes')}")

            st.markdown("### Executive Summary")
            st.write(report.get("executive_summary"))

            st.markdown("### Risk Assessment")
            st.write(report.get("risk_assessment_summary"))

            st.markdown("### Strategic Rebalance Action Plan")
            rebalance_data = report.get("rebalance_plan", [])
            if rebalance_data:
                df_rebalance = pd.DataFrame(rebalance_data)
                st.dataframe(df_rebalance, use_container_width=True)

            st.markdown("### Actionable Advisory Recommendations")
            for rec in report.get("actionable_recommendations", []):
                prio = rec.get("priority", "MEDIUM")
                prio_badge = f"badge-{prio.lower()}"
                with st.expander(f"[{prio}] {rec.get('title')} ({rec.get('category')})", expanded=True):
                    st.markdown(f"**Rationale:** {rec.get('rationale')}")
                    st.markdown("**Action Steps:**")
                    for step in rec.get("action_steps", []):
                        st.markdown(f"- {step}")

            st.caption(f"_{report.get('compliance_disclaimer')}_")

            # Download Report JSON
            st.download_button(
                label="📥 Download Structured Report (JSON)",
                data=json.dumps(report, indent=2),
                file_name=f"advisory_report_{client_id}.json",
                mime="application/json"
            )

    # TAB 5: Long-Term Memory & Trends
    with tab_memory:
        st.subheader("Long-Term Memory: Multi-Session Historical Tracking")
        st.write(f"Historical advisory snapshots and longitudinal trend detection for client `{client_id}`:")
        
        try:
            mem_resp = requests.get(f"{st.session_state.api_url}/api/v1/history/{client_id}", timeout=3)
            if mem_resp.status_code == 200:
                hist_records = mem_resp.json().get("history", [])
                if not hist_records:
                    st.info("No prior sessions recorded for this client. Current run establishes the baseline.")
                else:
                    st.write(f"Total Historical Sessions Recorded: **{len(hist_records)}**")
                    df_hist = pd.DataFrame([
                        {
                            "Session ID": r.get("session_id"),
                            "Timestamp": r.get("timestamp"),
                            "Net Worth ($)": f"${r.get('net_worth', 0):,.2f}",
                            "Total Assets ($)": f"${r.get('total_assets', 0):,.2f}",
                            "Health Score": f"{r.get('health_score')}/100",
                            "Anomalies Count": r.get("anomalies_count"),
                            "Advisor Notes": r.get("advisor_notes") or "None"
                        }
                        for r in hist_records
                    ])
                    st.dataframe(df_hist, use_container_width=True)
            else:
                st.error("Failed to query long-term memory store.")
        except Exception as e:
            st.error(f"Error querying memory store: {e}")

    # TAB 6: Observability & Audit Logs
    with tab_audit:
        st.subheader("Agent Execution Flow & Observability Trace")
        st.write("Detailed audit logging capturing agent routing, tool executions, and state checkpoints:")

        if audit_logs:
            for log in audit_logs:
                status_color = "🟢" if log.get("status") == "SUCCESS" else ("🟡" if log.get("status") in ["WARNING", "PAUSED"] else "🔴")
                st.markdown(
                    f"**{log.get('timestamp')}** {status_color} `[{log.get('agent_name')}]` **{log.get('action')}**  \n"
                    f"&nbsp;&nbsp;&nbsp;&nbsp;_{log.get('details')}_ (Status: `{log.get('status')}`)"
                )
        else:
            st.info("No audit logs available for this session.")

else:
    # Landing instructions
    st.info("👈 **Get Started**: Select a client scenario from the sidebar (or upload custom JSON) and click **'Run Multi-Agent Analysis'** to start the workflow.")
    
    st.markdown("### System Architecture Highlights")
    st.markdown("""
    - **Orchestrator Agent**: LangGraph StateGraph coordinating execution flow and conditional routing.
    - **Data Fetcher Agent**: Ingests JSON data, queries CRM API and Market Benchmark tools.
    - **Analyzer Agent**: Calculates Net Worth, asset allocations, debt leverage, and executes Anomaly Detection.
    - **Human-in-the-Loop Checkpoint**: Autonomous pause on critical anomalies; enables Wealth Advisor override.
    - **Advisory Agent**: Delivers structured rebalancing directives, health scores, and client recommendations.
    - **Memory Layer**: Short-Term session checkpointing + Persistent SQLite Long-Term Memory tracking historical drift.
    """)
