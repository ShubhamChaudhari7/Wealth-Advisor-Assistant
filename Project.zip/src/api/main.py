import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from src.models.schemas import (
    ClientFinancialData,
    HumanReviewRequest,
    WealthAdvisoryReport,
    CRMClientContext,
    FinancialAnalysisResult
)
from src.agents.orchestrator import WealthAdvisorOrchestrator
from src.memory.short_term import session_memory
from src.memory.long_term import LongTermMemoryStore
from src.tools.crm_tool import MockCRMClientTool
from src.tools.finance_tool import FinancialAnalysisTool
from src.tools.anomaly_tool import AnomalyDetectionTool
from src.tools.market_tool import MarketBenchmarkTool
from src.config import get_logger, GROQ_API_KEY, GROQ_MODEL

logger = get_logger("fastapi_app")

app = FastAPI(
    title="Wealth Advisor Multi-Agent AI System",
    description="Agent-based Wealth Advisor Assistant powered by LangChain, LangGraph, and FastAPI.",
    version="1.0.0"
)

# Enable CORS for frontend flexibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Instantiate core orchestrator and singletons
orchestrator = WealthAdvisorOrchestrator()
long_term_memory = LongTermMemoryStore()

# Tool registry for clean tool abstraction inspection
TOOLS_REGISTRY = {
    "crm_tool": MockCRMClientTool(),
    "finance_tool": FinancialAnalysisTool(),
    "anomaly_tool": AnomalyDetectionTool(),
    "market_benchmark_tool": MarketBenchmarkTool()
}

SAMPLES_DIR = Path(__file__).resolve().parent.parent.parent / "samples"

@app.get("/", response_class=HTMLResponse)
def root():
    return """<!DOCTYPE html>
<html>
<head>
    <title>Wealth Advisor Assistant API</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; margin: 0; }
        .card { background: #1e293b; border-radius: 12px; padding: 32px; max-width: 650px; margin: 40px auto; box-shadow: 0 10px 25px rgba(0,0,0,0.5); border: 1px solid #334155; }
        h1 { color: #38bdf8; margin: 12px 0 6px 0; font-size: 1.8rem; }
        p { color: #94a3b8; line-height: 1.5; margin-bottom: 24px; }
        .btn { display: inline-block; background: #2563eb; color: white; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 6px 6px 6px 0; font-size: 0.95rem; }
        .btn:hover { background: #1d4ed8; }
        .btn-secondary { background: #334155; color: #e2e8f0; }
        .btn-secondary:hover { background: #475569; }
        .status { display: inline-flex; align-items: center; gap: 6px; background: #14532d; color: #86efac; padding: 4px 12px; border-radius: 999px; font-size: 0.85rem; font-weight: 600; }
        .endpoints { background: #0f172a; border-radius: 8px; padding: 16px; margin-top: 24px; border: 1px solid #1e293b; }
        .endpoints code { color: #38bdf8; }
    </style>
</head>
<body>
    <div class="card">
        <span class="status">● Backend Online</span>
        <h1>💼 Wealth Advisor Assistant API</h1>
        <p>The FastAPI multi-agent backend is actively running. Choose an option below to explore the interactive API documentation or open the Streamlit user interface.</p>
        <div>
            <a class="btn" href="/docs">📖 Open Swagger API Docs (/docs)</a>
            <a class="btn" href="http://localhost:8501" target="_blank">🖥️ Open Streamlit UI (:8501)</a>
        </div>
        <div style="margin-top: 10px;">
            <a class="btn btn-secondary" href="/api/v1/health">🩺 Health Check</a>
            <a class="btn btn-secondary" href="/api/v1/clients">👥 Sample Clients</a>
        </div>
        <div class="endpoints">
            <small style="color: #64748b; font-weight: 600;">ACTIVE API ENDPOINTS</small>
            <ul style="margin: 8px 0 0 0; padding-left: 20px; color: #94a3b8; font-size: 0.9rem;">
                <li><code>POST /api/v1/analyze</code> — Multi-agent pipeline entrypoint</li>
                <li><code>POST /api/v1/review</code> — Human-in-the-Loop approval/override</li>
                <li><code>GET /api/v1/history/{client_id}</code> — Long-term memory query</li>
                <li><code>GET /api/v1/health</code> — Engine & model health status</li>
            </ul>
        </div>
    </div>
</body>
</html>"""

@app.get("/api/v1/health")
def health_check():
    if GROQ_API_KEY:
        llm_engine = "Groq LLM (LangChain)"
        model_name = GROQ_MODEL
    else:
        llm_engine = "Deterministic Expert Synthesizer (Zero-Key)"
        model_name = "Internal Rules Engine"

    return {
        "status": "healthy",
        "service": "Wealth Advisor Assistant",
        "llm_engine": llm_engine,
        "model": model_name,
        "active_short_term_sessions": len(session_memory.list_active_sessions()),
        "tools_loaded": list(TOOLS_REGISTRY.keys())
    }

@app.get("/api/v1/clients")
def list_sample_clients():
    """
    Returns available mock client datasets for rapid demonstration.
    """
    samples = []
    if SAMPLES_DIR.exists():
        for f in SAMPLES_DIR.glob("sample_client_*.json"):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                profile = data.get("client_profile", {})
                samples.append({
                    "filename": f.name,
                    "client_id": profile.get("client_id"),
                    "name": profile.get("name"),
                    "age": profile.get("age"),
                    "risk_tolerance": profile.get("risk_tolerance"),
                    "data": data
                })
            except Exception as e:
                logger.error(f"Error loading {f.name}: {e}")
    return {"clients": samples}

@app.post("/api/v1/analyze")
def run_financial_analysis(payload: Dict[str, Any]):
    """
    Initiates the multi-agent workflow.
    Routes tasks: Data Fetcher -> Analyzer -> Conditional Human-in-the-Loop Checkpoint or Advisory Agent.
    """
    try:
        session_id = payload.get("session_id")
        result = orchestrator.run_initial_analysis(
            financial_data=payload,
            session_id=session_id
        )
        return {
            "success": True,
            "session_id": result["session_id"],
            "client_id": result["client_id"],
            "status": result["status"],
            "current_step": result["current_step"],
            "requires_human_approval": result["requires_human_approval"],
            "is_approved_by_human": result["is_approved_by_human"],
            "analysis_result": result.get("analysis_result"),
            "anomalies": result.get("anomalies", []),
            "crm_context": result.get("crm_context"),
            "market_benchmarks": result.get("market_benchmarks"),
            "advisory_report": result.get("advisory_report"),
            "audit_logs": result.get("audit_logs", [])
        }
    except Exception as e:
        logger.error(f"Error running analysis: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/review")
def submit_human_review(review: HumanReviewRequest):
    """
    Human-in-the-Loop checkpoint resolution.
    Resumes workflow with human advisor authorization and optional strategic override instructions.
    """
    try:
        result = orchestrator.resume_with_human_decision(
            session_id=review.session_id,
            approved=review.approved,
            advisor_notes=review.advisor_notes
        )
        return {
            "success": True,
            "session_id": result["session_id"],
            "client_id": result["client_id"],
            "status": result["status"],
            "current_step": result["current_step"],
            "advisory_report": result.get("advisory_report"),
            "audit_logs": result.get("audit_logs", [])
        }
    except ValueError as ve:
        raise HTTPException(status_code=404, detail=str(ve))
    except Exception as e:
        logger.error(f"Error submitting review: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/history/{client_id}")
def get_client_history(client_id: str, limit: int = 10):
    """
    Queries Long-Term Memory Store for historical advisory sessions.
    """
    history = long_term_memory.get_client_history(client_id=client_id, limit=limit)
    return {
        "client_id": client_id,
        "total_historical_sessions": len(history),
        "history": history
    }

@app.post("/api/v1/tools/{tool_name}/execute")
def test_tool_abstraction(tool_name: str, params: Dict[str, Any]):
    """
    Clean interface to test each abstracted tool individually (Observability & Verification).
    """
    if tool_name not in TOOLS_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Tool '{tool_name}' not found. Available: {list(TOOLS_REGISTRY.keys())}")
    tool = TOOLS_REGISTRY[tool_name]
    res = tool.execute(**params)
    return res.model_dump()
