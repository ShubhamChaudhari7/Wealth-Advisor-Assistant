from typing import Dict, Any, Optional
from datetime import datetime
from src.config import get_logger

logger = get_logger("short_term_memory")

class SessionMemoryManager:
    """
    In-memory Short-Term Session Store.
    Preserves intermediate multi-agent execution state, user session context,
    and pending human-in-the-loop checkpoints across API requests.
    """
    def __init__(self):
        self._sessions: Dict[str, Dict[str, Any]] = {}

    def set_session(self, session_id: str, state: Dict[str, Any]) -> None:
        state["last_updated"] = datetime.now().isoformat()
        self._sessions[session_id] = state
        logger.debug(f"Saved short-term session {session_id} state.")

    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        return self._sessions.get(session_id)

    def delete_session(self, session_id: str) -> None:
        if session_id in self._sessions:
            del self._sessions[session_id]

    def list_active_sessions(self) -> Dict[str, Dict[str, Any]]:
        return {
            sid: {
                "client_id": s.get("client_id"),
                "status": s.get("status"),
                "last_updated": s.get("last_updated")
            }
            for sid, s in self._sessions.items()
        }

# Global singleton session manager
session_memory = SessionMemoryManager()
