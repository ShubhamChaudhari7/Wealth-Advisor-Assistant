import sqlite3
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from src.config import DB_PATH, get_logger

logger = get_logger("long_term_memory")

class LongTermMemoryStore:
    """
    Persistent Long-Term Memory Store backed by SQLite.
    Stores and retrieves historical financial snapshots, previous advisory summaries,
    and portfolio trends across multiple client review cycles.
    """
    def __init__(self, db_path=DB_PATH):
        self.db_path = str(db_path)
        self._init_db()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS client_historical_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    client_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    net_worth REAL NOT NULL,
                    total_assets REAL NOT NULL,
                    total_liabilities REAL NOT NULL,
                    health_score INTEGER NOT NULL,
                    asset_allocation_json TEXT NOT NULL,
                    executive_summary TEXT,
                    anomalies_count INTEGER DEFAULT 0,
                    advisor_notes TEXT
                )
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_client_history 
                ON client_historical_sessions(client_id, timestamp)
            """)
            conn.commit()

    def save_session(
        self,
        client_id: str,
        session_id: str,
        net_worth: float,
        total_assets: float,
        total_liabilities: float,
        health_score: int,
        asset_allocation: Dict[str, float],
        executive_summary: str,
        anomalies_count: int = 0,
        advisor_notes: Optional[str] = None
    ) -> None:
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO client_historical_sessions (
                        client_id, session_id, timestamp, net_worth, total_assets,
                        total_liabilities, health_score, asset_allocation_json,
                        executive_summary, anomalies_count, advisor_notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    client_id,
                    session_id,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    net_worth,
                    total_assets,
                    total_liabilities,
                    health_score,
                    json.dumps(asset_allocation),
                    executive_summary,
                    anomalies_count,
                    advisor_notes or ""
                ))
                conn.commit()
            logger.info(f"Saved long-term memory snapshot for client {client_id} (session: {session_id})")
        except Exception as e:
            logger.error(f"Failed to persist long-term memory: {e}")

    def get_client_history(self, client_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM client_historical_sessions
                    WHERE client_id = ?
                    ORDER BY id DESC
                    LIMIT ?
                """, (client_id, limit))
                rows = cursor.fetchall()

            history = []
            for row in rows:
                item = dict(row)
                item["asset_allocation"] = json.loads(item.get("asset_allocation_json", "{}"))
                history.append(item)
            return history
        except Exception as e:
            logger.error(f"Failed to retrieve client history for {client_id}: {e}")
            return []

    def get_historical_comparison(
        self,
        client_id: str,
        current_net_worth: float,
        current_allocation: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Compares current figures against the most recent prior advisory session.
        """
        history = self.get_client_history(client_id, limit=1)
        if not history:
            return {
                "has_previous_session": False,
                "message": "First advisory session on record. Establishing historical baseline."
            }

        prev = history[0]
        prev_nw = prev.get("net_worth", 0.0)
        nw_change = current_net_worth - prev_nw
        nw_pct_change = round((nw_change / prev_nw * 100) if prev_nw != 0 else 0.0, 2)

        prev_alloc = prev.get("asset_allocation", {})
        drift_notes = []
        for cat, curr_pct in current_allocation.items():
            past_pct = prev_alloc.get(cat, 0.0)
            diff = curr_pct - past_pct
            if abs(diff) >= 5.0:
                direction = "increased" if diff > 0 else "decreased"
                drift_notes.append(f"{cat} has {direction} by {abs(diff):.1f}% since last session.")

        return {
            "has_previous_session": True,
            "previous_session_date": prev.get("timestamp"),
            "previous_net_worth": prev_nw,
            "net_worth_change": round(nw_change, 2),
            "net_worth_pct_change": nw_pct_change,
            "previous_health_score": prev.get("health_score"),
            "historical_drift_notes": drift_notes,
            "previous_summary": prev.get("executive_summary")
        }
