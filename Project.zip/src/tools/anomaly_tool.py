from typing import Dict, Any, List
import uuid
from src.tools.base import BaseAgentTool
from src.models.schemas import Anomaly

class AnomalyDetectionTool(BaseAgentTool):
    """
    Tool abstraction for identifying anomalous financial activities,
    unusual transactions, rapid capital outflows, and risk profile deviations.
    """
    name: str = "anomaly_detection_tool"
    description: str = "Detects unusual transactions, sudden outflows, risk tolerance drift, and leverage red flags."

    def _run(self, financial_data: Dict[str, Any], analysis_result: Dict[str, Any]) -> List[Dict[str, Any]]:
        profile = financial_data.get("client_profile", {})
        transactions = financial_data.get("transactions", [])
        risk_tolerance = profile.get("risk_tolerance", "Moderate").capitalize()
        asset_alloc = analysis_result.get("asset_allocation", {})
        emergency_months = analysis_result.get("emergency_fund_months", 0.0)
        debt_to_asset = analysis_result.get("debt_to_asset_ratio", 0.0)
        monthly_income = float(profile.get("current_annual_income", 100000.0)) / 12.0
        
        anomalies: List[Dict[str, Any]] = []

        # 1. Unusual Transaction Detection
        if transactions:
            amounts = [abs(float(t.get("amount", 0.0))) for t in transactions]
            avg_amount = sum(amounts) / len(amounts) if amounts else 0.0

            for t in transactions:
                amt = abs(float(t.get("amount", 0.0)))
                t_type = t.get("transaction_type", "").upper()
                desc = t.get("description", "")
                t_id = t.get("transaction_id", f"TXN-{uuid.uuid4().hex[:6]}")

                # Flag massive single transaction (> 3x average AND > $10,000)
                if amt > (avg_amount * 3.0) and amt >= 10000.0:
                    severity = "CRITICAL" if amt >= 50000.0 else "HIGH"
                    anomalies.append(Anomaly(
                        id=f"ANOM-{uuid.uuid4().hex[:6]}",
                        severity=severity,
                        category="UNUSUAL_TRANSACTION",
                        description=f"Transaction '{desc}' of ${amt:,.2f} is significantly higher than historical average (${avg_amount:,.2f}).",
                        detected_value=amt,
                        threshold_or_benchmark=round(avg_amount * 3.0, 2),
                        actionable_fix="Verify client authorization and assess if this represents an uncharacteristic capital outflow or one-off expenditure."
                    ).model_dump())

                # Suspicious transaction keywords (e.g., gambling, unverified offshore wire, crypto exchange burst)
                suspicious_keywords = ["casino", "crypto wire", "unregistered broker", "betting", "luxury impulse"]
                if any(kw in desc.lower() for kw in suspicious_keywords):
                    anomalies.append(Anomaly(
                        id=f"ANOM-{uuid.uuid4().hex[:6]}",
                        severity="HIGH",
                        category="UNUSUAL_TRANSACTION",
                        description=f"Suspicious merchant/activity detected: '{desc}' for ${amt:,.2f}.",
                        detected_value=desc,
                        threshold_or_benchmark="Standard approved merchant categories",
                        actionable_fix="Request transaction verification and review client wealth preservation covenants."
                    ).model_dump())

            # 2. Rapid Outflows Analysis
            outflows = [
                float(t.get("amount", 0.0))
                for t in transactions
                if t.get("transaction_type", "").upper() in ["WITHDRAWAL", "EXPENSE"]
            ]
            total_outflow = sum(outflows)
            if monthly_income > 0 and total_outflow > (monthly_income * 1.5):
                anomalies.append(Anomaly(
                    id=f"ANOM-{uuid.uuid4().hex[:6]}",
                    severity="HIGH",
                    category="RAPID_OUTFLOW",
                    description=f"Total recent outflow of ${total_outflow:,.2f} exceeds 150% of client's monthly income (${monthly_income:,.2f}).",
                    detected_value=round(total_outflow, 2),
                    threshold_or_benchmark=round(monthly_income * 1.5, 2),
                    actionable_fix="Assess burn rate velocity; schedule proactive client liquidity check-in."
                ).model_dump())

        # 3. Risk Tolerance vs Portfolio Allocation Mismatch (Risk Drift)
        equity_pct = asset_alloc.get("Equity", 0.0)
        crypto_pct = asset_alloc.get("Crypto", 0.0)
        cash_pct = asset_alloc.get("Cash", 0.0)
        fixed_income_pct = asset_alloc.get("Fixed Income", 0.0)

        if risk_tolerance == "Conservative":
            if equity_pct > 40.0:
                anomalies.append(Anomaly(
                    id=f"ANOM-{uuid.uuid4().hex[:6]}",
                    severity="HIGH",
                    category="RISK_MISMATCH",
                    description=f"Conservative risk mandate violated: Equity exposure is {equity_pct:.1f}% (target ceiling: 35%).",
                    detected_value=f"{equity_pct:.1f}%",
                    threshold_or_benchmark="35.0%",
                    actionable_fix="Execute strategic rebalancing: Trim overweighted equities and reallocate to short-duration fixed income or treasury funds."
                ).model_dump())
            if crypto_pct > 2.0:
                anomalies.append(Anomaly(
                    id=f"ANOM-{uuid.uuid4().hex[:6]}",
                    severity="CRITICAL",
                    category="RISK_MISMATCH",
                    description=f"Conservative risk mandate violated: Speculative crypto holding at {crypto_pct:.1f}% (target ceiling: <= 1%).",
                    detected_value=f"{crypto_pct:.1f}%",
                    threshold_or_benchmark="1.0%",
                    actionable_fix="Advise immediate derisking of volatile digital assets to safeguard principal capital."
                ).model_dump())

        elif risk_tolerance == "Aggressive":
            if cash_pct > 45.0:
                anomalies.append(Anomaly(
                    id=f"ANOM-{uuid.uuid4().hex[:6]}",
                    severity="MEDIUM",
                    category="RISK_MISMATCH",
                    description=f"Aggressive growth mandate drag: Cash allocation is {cash_pct:.1f}%, creating severe inflation drag.",
                    detected_value=f"{cash_pct:.1f}%",
                    threshold_or_benchmark="10.0%",
                    actionable_fix="Deploy idle cash reserves via dollar-cost averaging into index equity and growth opportunities."
                ).model_dump())

        # 4. Leverage / Debt Burden
        if debt_to_asset > 0.50:
            anomalies.append(Anomaly(
                id=f"ANOM-{uuid.uuid4().hex[:6]}",
                severity="HIGH",
                category="HIGH_DEBT",
                description=f"Elevated financial leverage: Debt-to-asset ratio is {debt_to_asset * 100:.1f}%, exceeding 50% prudential guideline.",
                detected_value=f"{debt_to_asset * 100:.1f}%",
                threshold_or_benchmark="50.0%",
                actionable_fix="Develop accelerated debt amortization roadmap prioritizing high-interest liabilities."
            ).model_dump())

        # 5. Liquidity / Emergency Buffer Depletion
        if emergency_months < 3.0:
            anomalies.append(Anomaly(
                id=f"ANOM-{uuid.uuid4().hex[:6]}",
                severity="HIGH",
                category="CONCENTRATION_RISK",
                description=f"Critical liquidity shortfall: Client has only {emergency_months:.1f} months of emergency expense reserves.",
                detected_value=f"{emergency_months:.1f} months",
                threshold_or_benchmark="3.0 - 6.0 months",
                actionable_fix="Replenish emergency cash reserves to at least 3-6 months in high-yield liquid accounts."
            ).model_dump())

        return anomalies
