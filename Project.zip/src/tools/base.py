from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field
import time

class ToolResult(BaseModel):
    success: bool
    data: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = Field(default_factory=dict)

class BaseAgentTool(ABC):
    """
    Abstract interface for all multi-agent system tools.
    Decouples agent logic from raw external implementations,
    providing unified error handling, timing, and observability.
    """
    name: str = "base_tool"
    description: str = "Base agent tool description"

    def execute(self, **kwargs) -> ToolResult:
        start_time = time.perf_counter()
        try:
            result_data = self._run(**kwargs)
            duration = (time.perf_counter() - start_time) * 1000
            return ToolResult(
                success=True,
                data=result_data,
                execution_time_ms=round(duration, 2),
                metadata={"tool": self.name}
            )
        except Exception as e:
            duration = (time.perf_counter() - start_time) * 1000
            return ToolResult(
                success=False,
                error=f"Tool [{self.name}] execution failed: {str(e)}",
                execution_time_ms=round(duration, 2),
                metadata={"tool": self.name}
            )

    @abstractmethod
    def _run(self, **kwargs) -> Any:
        """Internal execution implementation to be implemented by specific tools."""
        pass
