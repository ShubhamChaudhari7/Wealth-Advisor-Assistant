from typing import Dict, Any, List
from src.tools.base import BaseAgentTool

class FinancialAnalysisTool(BaseAgentTool):
    """
    Tool abstraction for performing core quantitative wealth analysis:
    Net worth, asset allocation, leverage ratios, cash flow buffer, and concentration metrics.
    """
    name: str = "financial_analysis_tool"
    description: str = "Computes asset allocation, net worth, leverage ratios, and concentration risks from portfolio data."

    def _run(self, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        profile = financial_data.get("client_profile", {})
        assets = financial_data.get("assets", [])
        liabilities = financial_data.get("liabilities", [])
        
        # 1. Total Assets & Category Breakdown
        total_assets = sum(float(a.get("market_value", 0.0)) for a in assets)
        total_cost_basis = sum(float(a.get("cost_basis", 0.0)) for a in assets)
        total_unrealized_gain_loss = sum(float(a.get("unrealized_gain_loss", 0.0)) for a in assets)
        
        category_amounts: Dict[str, float] = {}
        category_percentages: Dict[str, float] = {}
        concentration_risks: List[str] = []

        for a in assets:
            cat = a.get("category", "Other")
            val = float(a.get("market_value", 0.0))
            category_amounts[cat] = category_amounts.get(cat, 0.0) + val
            
            # Check single asset concentration (> 25% of total wealth)
            if total_assets > 0:
                pct = (val / total_assets) * 100
                if pct > 25.0:
                    concentration_risks.append(
                        f"Concentration Risk: '{a.get('asset_name', 'Unnamed Asset')}' accounts for {pct:.1f}% of total assets (${val:,.2f})."
                    )

        if total_assets > 0:
            for cat, amount in category_amounts.items():
                category_percentages[cat] = round((amount / total_assets) * 100, 2)
        else:
            category_percentages = {cat: 0.0 for cat in category_amounts}

        # 2. Total Liabilities
        total_liabilities = sum(float(l.get("outstanding_balance", 0.0)) for l in liabilities)
        total_monthly_debt_payments = sum(float(l.get("monthly_payment", 0.0)) for l in liabilities)

        # 3. Net Worth & Ratios
        net_worth = total_assets - total_liabilities
        debt_to_asset_ratio = round((total_liabilities / total_assets) if total_assets > 0 else 0.0, 4)

        # 4. Cash Flow & Liquidity
        monthly_income = float(profile.get("current_annual_income", 0.0)) / 12.0
        monthly_expenses = float(profile.get("monthly_expenses", 0.0))
        monthly_cash_flow_surplus = round(monthly_income - monthly_expenses - total_monthly_debt_payments, 2)

        cash_assets = category_amounts.get("Cash", 0.0)
        emergency_fund_months = round(
            (cash_assets / monthly_expenses) if monthly_expenses > 0 else 0.0, 1
        )

        return {
            "total_assets": round(total_assets, 2),
            "total_liabilities": round(total_liabilities, 2),
            "net_worth": round(net_worth, 2),
            "debt_to_asset_ratio": debt_to_asset_ratio,
            "asset_allocation": category_percentages,
            "asset_allocation_amounts": {k: round(v, 2) for k, v in category_amounts.items()},
            "monthly_cash_flow_surplus": monthly_cash_flow_surplus,
            "emergency_fund_months": emergency_fund_months,
            "portfolio_unrealized_gain_loss": round(total_unrealized_gain_loss, 2),
            "concentration_risks": concentration_risks,
            "monthly_debt_payments": round(total_monthly_debt_payments, 2)
        }
