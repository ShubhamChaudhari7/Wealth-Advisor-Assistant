from typing import Dict, Any
from src.tools.base import BaseAgentTool

class MarketBenchmarkTool(BaseAgentTool):
    """
    Tool abstraction for querying macro financial indicators and benchmark target allocations.
    """
    name: str = "market_benchmark_tool"
    description: str = "Retrieves macroeconomic benchmark rates, inflation benchmarks, and model target portfolio allocations."

    TARGET_ALLOCATIONS: Dict[str, Dict[str, float]] = {
        "Conservative": {
            "Equity": 25.0,
            "Fixed Income": 55.0,
            "Cash": 15.0,
            "Real Estate": 5.0,
            "Crypto": 0.0,
            "Alternative": 0.0
        },
        "Moderate": {
            "Equity": 55.0,
            "Fixed Income": 30.0,
            "Cash": 5.0,
            "Real Estate": 10.0,
            "Crypto": 0.0,
            "Alternative": 0.0
        },
        "Aggressive": {
            "Equity": 75.0,
            "Fixed Income": 10.0,
            "Cash": 5.0,
            "Real Estate": 5.0,
            "Crypto": 3.0,
            "Alternative": 2.0
        }
    }

    MACRO_BENCHMARKS = {
        "sp500_ytd_return_pct": 14.8,
        "us_agg_bond_index_yield_pct": 4.6,
        "us_10yr_treasury_yield_pct": 4.25,
        "fed_funds_rate_pct": 5.00,
        "cpi_inflation_rate_pct": 2.9,
        "high_yield_savings_avg_pct": 4.5
    }

    def _run(self, risk_tolerance: str = "Moderate") -> Dict[str, Any]:
        normalized_risk = risk_tolerance.capitalize()
        target = self.TARGET_ALLOCATIONS.get(normalized_risk, self.TARGET_ALLOCATIONS["Moderate"])
        
        return {
            "risk_profile": normalized_risk,
            "target_model_allocation": target,
            "macro_benchmarks": self.MACRO_BENCHMARKS
        }
