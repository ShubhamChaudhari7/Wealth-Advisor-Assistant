from typing import Dict, Any, Optional
from src.tools.base import BaseAgentTool
from src.models.schemas import CRMClientContext

class MockCRMClientTool(BaseAgentTool):
    """
    Tool abstraction for interacting with external CRM APIs.
    Simulates CRM records, client history, tax status, and relationship notes.
    """
    name: str = "crm_tool"
    description: str = "Fetches client profile, KYC compliance, relationship status, and advisory goals from the CRM system."

    # Simulated CRM Database
    MOCK_CRM_STORE: Dict[str, Dict[str, Any]] = {
        "CLI-1001": {
            "client_id": "CLI-1001",
            "relationship_status": "Active VIP",
            "advisor_assigned": "Sarah Jenkins, CFP",
            "last_meeting_date": "2024-08-15",
            "stated_goals": ["Capital Preservation", "Generate Steady Income", "Wealth Transfer to Heirs"],
            "tax_bracket_pct": 28.0,
            "liquidity_needs_notes": "Prefers maintaining at least 12 months emergency liquid buffer.",
            "kyc_verified": True,
            "crm_source": "Salesforce Financial Services Cloud (Simulated)"
        },
        "CLI-1002": {
            "client_id": "CLI-1002",
            "relationship_status": "Active Growth",
            "advisor_assigned": "David Chen, CFA",
            "last_meeting_date": "2024-09-01",
            "stated_goals": ["Aggressive Capital Growth", "Tech Startup Equity Diversification", "Retire by 50"],
            "tax_bracket_pct": 35.0,
            "liquidity_needs_notes": "High risk appetite, accepts short-term volatility for multi-year upside.",
            "kyc_verified": True,
            "crm_source": "Wealthbox CRM (Simulated)"
        },
        "CLI-1003": {
            "client_id": "CLI-1003",
            "relationship_status": "Under Review",
            "advisor_assigned": "Elena Rostova, ChFC",
            "last_meeting_date": "2024-05-10",
            "stated_goals": ["Balanced Growth", "Purchase Vacation Property in 3 Years"],
            "tax_bracket_pct": 24.0,
            "liquidity_needs_notes": "Needs liquid funds available within 24-36 months for real estate down payment.",
            "kyc_verified": True,
            "crm_source": "Simulated Enterprise CRM"
        }
    }

    def _run(self, client_id: str, simulate_failure: bool = False) -> Dict[str, Any]:
        if simulate_failure:
            raise ConnectionError(f"Simulated CRM API timeout when accessing client {client_id}")

        if client_id in self.MOCK_CRM_STORE:
            return self.MOCK_CRM_STORE[client_id]

        # Dynamic fallback for arbitrary client IDs
        return {
            "client_id": client_id,
            "relationship_status": "New Client",
            "advisor_assigned": "General Wealth Advisory Desk",
            "last_meeting_date": "Recent Intake",
            "stated_goals": ["Comprehensive Financial Assessment", "Retirement Planning"],
            "tax_bracket_pct": 22.0,
            "liquidity_needs_notes": "Standard 6-month reserve guideline applies.",
            "kyc_verified": True,
            "crm_source": "Default Intake CRM Connector"
        }
