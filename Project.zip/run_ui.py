import sys
import subprocess
import os

if __name__ == "__main__":
    port = os.getenv("STREAMLIT_PORT", "8501")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "src/ui/app.py",
        "--server.port",
        port,
        "--server.headless",
        "false"
    ]
    print(f"Starting Wealth Advisor Streamlit Dashboard on port {port}...")
    subprocess.run(cmd)
