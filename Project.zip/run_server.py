import uvicorn
import os
from dotenv import load_dotenv

load_dotenv()

if __name__ == "__main__":
    host = os.getenv("FASTAPI_HOST", "127.0.0.1")
    port = int(os.getenv("FASTAPI_PORT", 8000))
    print(f"Starting Wealth Advisor FastAPI Backend on http://{host}:{port}...")
    uvicorn.run("src.api.main:app", host=host, port=port, reload=True)
