import json
import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
from src.agents.orchestrator import WealthAdvisorOrchestrator
from src.tools.crm_tool import MockCRMClientTool
from src.tools.finance_tool import FinancialAnalysisTool
from src.tools.anomaly_tool import AnomalyDetectionTool

def main():
    print("Testing Wealth Advisor Multi-Agent Pipeline...")
    with open("samples/sample_client_conservative.json", "r") as f:
        client_data = json.load(f)

    orchestrator = WealthAdvisorOrchestrator()
    res = orchestrator.run_initial_analysis(client_data)
    
    print("\nInitial Run Status:", res.get("status"))
    print("Requires Human Approval:", res.get("requires_human_approval"))
    print("Anomalies Found:", len(res.get("anomalies", [])))
    for a in res.get("anomalies", []):
        print(f" - [{a['severity']}] {a['category']}: {a['description']}")

    if res.get("status") == "AWAITING_HUMAN_APPROVAL":
        print("\nTesting Human-in-the-Loop Approval & Strategic Advisor Override...")
        session_id = res["session_id"]
        res2 = orchestrator.resume_with_human_decision(
            session_id=session_id,
            approved=True,
            advisor_notes="Approved rebalancing plan. Client instructed to keep $10k in crypto and trim equity by 15%."
        )
        print("Resumed Run Status:", res2.get("status"))
        report = res2.get("advisory_report")
        print("Financial Health Score:", report.get("financial_health_score"))
        print("Executive Summary:\n", report.get("executive_summary"))
        print("\nRebalancing Recommendations Count:", len(report.get("rebalance_plan", [])))
        print("Actionable Recommendations Count:", len(report.get("actionable_recommendations", [])))

    print("\nTest completed successfully!")

if __name__ == "__main__":
    main()
